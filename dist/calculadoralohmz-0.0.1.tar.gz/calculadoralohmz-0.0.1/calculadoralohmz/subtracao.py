def subtracao(a,b):
    resultado = a - b
    print(resultado)