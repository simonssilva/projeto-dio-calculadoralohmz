def multiplicacao(a,b):
    resultado = a * b
    print(resultado)