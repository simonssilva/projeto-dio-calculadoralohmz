def soma(a,b):
    resultado = a + b
    print(resultado)