# calculadora

Description. 
The package calculadora is used to:
	- Calculadora bem básica para calculo de dois valores.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install calculadora

```bash
pip install calculadoralohmz
```

## Usage

```python
from calculadora import divisao
divisao.divisao(a,b)
```
from calculadora import multiplicacao
multiplicacao.multiplicacao(a,b)
```
from calculadora import soma
soma.soma(a,b)
```
from calculadora import subtracao
subtracao.subtracao(a,b)
```

## Author
Simon

## License
[MIT](https://choosealicense.com/licenses/mit/)