def divisao(a,b):
    resultado = a / b
    print(resultado)
